#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "LineParser.h"

#ifndef NULL
    #define NULL 0
#endif

#ifndef PATH_MAX
    #define PATH_MAX 1024
#endif  

#define FREE(X) if(X) free((void*)X)

int debug, inRedirect, outRedirect, pipeFlag = 0;


void execute(cmdLine *pCmdLine) {
    int pipefd[2];
    pid_t child_1, child_2;
    int status1, status2;

    FILE* inFile;
    FILE* outFile;
    
    if(pipeFlag) {
        if(pipe(pipefd) == -1) {
            perror("pipe error occurred");
            exit(1);
        }
    }
    
    child_1 = fork();
            
    if(child_1 == -1) {
        if(debug) { fprintf(stderr, "PID: %d\n", child_1); }
        perror("fork error occurred");
        exit(1);
    }
    
    if(child_1 == 0) 
    { 
        if(debug) { fprintf(stderr, "PID: %d\n", child_1); }
        
        if(pipeFlag) {
            fclose(stdout);     
            dup(pipefd[1]);     
            close(pipefd[1]);
            if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
                perror("execvp error occurred");
                _exit(-1);
            }
            _exit(0);
        }
        
        else {
            if(inRedirect) {
                fclose(stdin);
                inFile = fopen(pCmdLine->inputRedirect, "r"); //open for reading
            }
            if(outRedirect) {
                fclose(stdout);
                outFile = fopen(pCmdLine->outputRedirect,"w"); //open for writing
            }
        
            if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
                perror("execvp error occurred");
                _exit(-1);
            }
            
            if(inRedirect) {
                fclose(inFile);
                inRedirect = 0;
            }
            
            if(outRedirect) {
                fclose(outFile);
                outRedirect = 0;
            }
            _exit(0);
        }
    }
    
    else        //parent process
    {
        if(debug) { fprintf(stderr, "PID: %d\n", child_1); }
        
        if(pipeFlag) { 
            close(pipefd[1]);
            child_2 = fork();
            
            if(child_2 == -1) {
                perror("fork2 error occurred");
                exit(1);
            }

            if(child_2 == 0) {     
                fclose(stdin);     
                dup(pipefd[0]);     
                close(pipefd[0]);   
                
                if(execvp(pCmdLine->next->arguments[0], pCmdLine->next->arguments) < 0) {
                    perror("execvp error occurred");
                    _exit(-1);
                }
                _exit(0);
            } 
            
            else {        
                close(pipefd[0]);
            }
            
            waitpid(child_1, &status1, 0);
            waitpid(child_2, &status2, 0);
            pipeFlag = 0;
        }
            
        else if(pCmdLine->blocking == 1) { waitpid(child_1, &status1, 0); }
    }
}


void my_cd(cmdLine *pCmdLine)
{    
    if(chdir(pCmdLine->arguments[1]) < 0) {
        perror("chdir error occurred");
        exit(1);
    }
}



int main(int argc, char *argv[]){
    char cwdBuf[PATH_MAX];
    char readBuf[2048];
    cmdLine* pCmdLine;
     
    while(1){
        
        if(argc > 1) debug = 1;    
        
        if(debug) { fprintf(stderr, "PID: %d\n", getpid()); }
        
        getcwd(cwdBuf, (PATH_MAX));
       
        fprintf(stdout, ">%s ", cwdBuf);
        
        fgets(readBuf, sizeof(readBuf), stdin);
        
        if(strcmp(readBuf, "quit\n") == 0) { exit(0); }
        
        pCmdLine = parseCmdLines(readBuf);
        
        if(debug) { fprintf(stderr, "Executing command: %s\n", pCmdLine->arguments[0]); }
        
        if(strcmp(pCmdLine->arguments[0], "cd") == 0) {
            my_cd(pCmdLine);
            freeCmdLines(pCmdLine);
        }
        
        else {
            if(pCmdLine->next != NULL) { pipeFlag = 1; }
            if(pCmdLine->inputRedirect != NULL) { inRedirect = 1; }
            if(pCmdLine->outputRedirect != NULL) { outRedirect = 1; }
            execute(pCmdLine);
            freeCmdLines(pCmdLine);
        }
    }
    
    return 0;
}