#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "LineParser.h"

#ifndef NULL
    #define NULL 0
#endif

#ifndef PATH_MAX
    #define PATH_MAX 1024
#endif  

#define FREE(X) if(X) free((void*)X)

typedef struct strPair {
	char *name;
	char *value;
	struct strPair *next;
} strPair;


strPair* strPair_list = NULL;
int debug, inRedirect, outRedirect, pipeFlag = 0;


strPair* searchPair(strPair* strPair_list, char* name) {
    
    strPair* tmp = strPair_list; /* keep pointing at head */
    
    while(tmp) {
        if(strcmp(tmp->name, name) == 0) {
            return tmp;
        } else
            tmp = tmp->next;
    }
    return NULL;
}


void setPair(strPair** strPair_list, cmdLine* cmd) {
    
    strPair* toOverride = searchPair(*strPair_list, cmd->arguments[1]);
    if(toOverride) {
        free(toOverride->value);
        toOverride->value = strdup(cmd->arguments[2]);
        return;
    }
    
    strPair* newPair = (strPair*)malloc(sizeof(strPair));
    
    if(newPair == NULL) {
        fprintf(stdout, "malloc error occurred");
        exit(1);
    }

    newPair->name = strdup(cmd->arguments[1]);

    newPair->value = strdup(cmd->arguments[2]);
    
    newPair->next = NULL;
        
    if(!(*strPair_list)) 
        *strPair_list = newPair;
    
    else {
        strPair* tmp = *strPair_list; /* keep pointing at head */
        while(tmp->next) {
            tmp = tmp->next;
        }
        tmp->next = newPair;
    }
}
    
    
void printInvars(strPair** strPair_list) {
    if(!(*strPair_list)) { 
        fprintf(stdout, "internal variables list is empty\n"); 
        return;
    }
    
    fprintf(stdout, "NAME\tVALUE\n");
    
    strPair* tmp = *strPair_list; /* keep pointing at head */
            
    while(tmp) 
    {
        fprintf(stdout, "%s\t%s\n", tmp->name, tmp->value);
        tmp = tmp->next;
    }
}



/* Given a reference (pointer to pointer) to the head of a list 
   and a key, deletes the first occurrence of key in linked list */
void deletePair(strPair** strPair_list, char* name) 
{ 
    // Store head node 
    strPair* temp = *strPair_list, *prev; 
  
    // If head node itself holds the key to be deleted 
    if ((temp != NULL) && (strcmp(temp->name, name) == 0)) 
    { 
        *strPair_list = temp->next;   // Changed head 
        free(temp->name);
        free(temp->value);
        free(temp);               // free old head 
        return; 
    } 
  
    // Search for the key to be deleted, keep track of the 
    // previous node as we need to change 'prev->next' 
    while ((temp != NULL) && (strcmp(temp->name, name) != 0)) 
    { 
        prev = temp; 
        temp = temp->next; 
    } 
  
    // If key was not present in linked list 
    if (temp == NULL) {
        fprintf(stderr, "given name was not present in internal variables list\n");
        return;
    }
  
    // Unlink the node from linked list 
    prev->next = temp->next; 
  
    free(temp->name);
    free(temp->value);
    free(temp);  // Free memory
    *strPair_list = NULL;
}   


void execute(cmdLine *pCmdLine) {
    int pipefd[2];
    pid_t child_1, child_2;
    int status1, status2;

    FILE* inFile;
    FILE* outFile;
    
    if(pipeFlag) {
        if(pipe(pipefd) == -1) {
            perror("pipe error occurred");
            exit(1);
        }
    }
    
    child_1 = fork();
            
    if(child_1 == -1) {
        if(debug) { fprintf(stderr, "PID: %d\n", child_1); }
        perror("fork error occurred");
        exit(1);
    }
    
    if(child_1 == 0) 
    { 
        if(debug) { fprintf(stderr, "PID: %d\n", child_1); }
        
        if(pipeFlag) {
            fclose(stdout);     
            dup(pipefd[1]);     
            close(pipefd[1]);
            if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
                perror("execvp error occurred");
                _exit(-1);
            }
            _exit(0);
        }
        
        else {
            if(inRedirect) {
                fclose(stdin);
                inFile = fopen(pCmdLine->inputRedirect, "r"); //open for reading
            }
            if(outRedirect) {
                fclose(stdout);
                outFile = fopen(pCmdLine->outputRedirect,"w"); //open for writing
            }
        
            if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
                perror("execvp error occurred");
                _exit(-1);
            }
            
            if(inRedirect) {
                fclose(inFile);
                inRedirect = 0;
            }
            
            if(outRedirect) {
                fclose(outFile);
                outRedirect = 0;
            }
            _exit(0);
        }
    }
    
    else        //parent process
    {
        if(debug) { fprintf(stderr, "PID: %d\n", child_1); }
        
        if(pipeFlag) { 
            close(pipefd[1]);
            child_2 = fork();
            
            if(child_2 == -1) {
                perror("fork2 error occurred");
                exit(1);
            }

            if(child_2 == 0) {     
                fclose(stdin);     
                dup(pipefd[0]);     
                close(pipefd[0]);   
                
                if(execvp(pCmdLine->next->arguments[0], pCmdLine->next->arguments) < 0) {
                    perror("execvp error occurred");
                    _exit(-1);
                }
                _exit(0);
            } 
            
            else {        
                close(pipefd[0]);
            }
            
            waitpid(child_1, &status1, 0);
            waitpid(child_2, &status2, 0);
            pipeFlag = 0;
        }
            
        else if(pCmdLine->blocking == 1) { waitpid(child_1, &status1, 0); }
    }
}


void my_cd(cmdLine *pCmdLine)
{
    if(chdir(pCmdLine->arguments[1]) < 0) {
        perror("chdir error occurred");
        exit(1);
    }
}



int main(int argc, char *argv[]){
    char cwdBuf[PATH_MAX];
    char readBuf[2048];
    cmdLine* pCmdLine;
    int i = 1;
     
    while(1){
        
        if(argc > 1) debug = 1;    
        
        if(debug) { fprintf(stderr, "PID: %d\n", getpid()); }
        
        getcwd(cwdBuf, (PATH_MAX));
       
        fprintf(stdout, ">%s ", cwdBuf);
        
        fgets(readBuf, sizeof(readBuf), stdin);
        
        if(strcmp(readBuf, "quit\n") == 0) { exit(0); }
        
        pCmdLine = parseCmdLines(readBuf);
        
        if(debug) { fprintf(stderr, "Executing command: %s\n", pCmdLine->arguments[0]); }
        
        while(pCmdLine->arguments[i]) { 
           if(strncmp(pCmdLine->arguments[i], "$", 1) == 0) {
               strPair* toReplace = searchPair(strPair_list, pCmdLine->arguments[i]+1);
               replaceCmdArg(pCmdLine, i, toReplace->value);
           }
           i += 1;
        }
        
        i = 1;
        
        if(strcmp(pCmdLine->arguments[0], "cd") == 0) {
            if(strcmp(pCmdLine->arguments[1], "~") == 0) {
                char* homeDir = getenv("HOME");
                replaceCmdArg(pCmdLine, 1, homeDir);
            }
            my_cd(pCmdLine);
            freeCmdLines(pCmdLine);
        }
        
        else if(strcmp(pCmdLine->arguments[0], "set") == 0) {
                setPair(&strPair_list, pCmdLine);
                freeCmdLines(pCmdLine);
        }
        
        else if(strcmp(pCmdLine->arguments[0], "vars") == 0) {
                printInvars(&strPair_list);
                freeCmdLines(pCmdLine);
        }
        
        else if(strcmp(pCmdLine->arguments[0], "delete") == 0) {
                deletePair(&strPair_list, pCmdLine->arguments[1]);
                freeCmdLines(pCmdLine);
        }
        
        else {
            if(pCmdLine->next != NULL) { pipeFlag = 1; }
            if(pCmdLine->inputRedirect != NULL) { inRedirect = 1; }
            if(pCmdLine->outputRedirect != NULL) { outRedirect = 1; }
            execute(pCmdLine);
            freeCmdLines(pCmdLine);
        }
    }
    
    return 0;
}