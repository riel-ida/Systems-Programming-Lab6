#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int pipefd[2];
    pid_t child_1;
    pid_t child_2;
    int status1, status2;
    int debug = 0;
    
    char *lsCmd = "ls";
    char *lsArgs[3];
    lsArgs[0] = "ls";
    lsArgs[1] = "-l";
    lsArgs[2] = NULL;
    
    char *tailCmd = "tail";
    char *tailArgs[4];
    tailArgs[0] = "tail";
    tailArgs[1] = "-n";
    tailArgs[2] = "2";
    tailArgs[3] = NULL;
    
    if(argc > 1) debug = 1;
    
    if (pipe(pipefd) == -1) {       // step1
        perror("pipe error occurred");
        exit(1);
    }

    if(debug) { fprintf(stderr, "(parent_process>forking…)\n"); }
    
    child_1 = fork();       // step2 
    
    if(debug) { fprintf(stderr, "(parent_process>created process with id: %d)\n", child_1); }
    
    if(child_1 == -1) {
        perror("fork1 error occurred");
        exit(1);
    }

    if(child_1 == 0) {     // step3 
        if(debug) { fprintf(stderr, "(child1>redirecting stdout to the write end of the pipe…)\n"); }
        fclose(stdout);     // 3.a
        dup(pipefd[1]);     // 3.b
        close(pipefd[1]);   // 3.c
        
        if(debug) { fprintf(stderr, "(child1>going to execute cmd: ls -l…)\n"); }
        if(execvp(lsCmd, lsArgs) < 0) {     // 3.d
            perror("execvp error occurred");
            _exit(-1);
        }
        _exit(0);

    } else {    // step4
        if(debug) { fprintf(stderr, "(parent_process>closing the write end of the pipe…)\n"); }
        close(pipefd[1]); 
      }           
    
    if(debug) { fprintf(stderr, "(parent_process>forking…)\n"); }
    
    child_2 = fork();       // step5
    
    if(debug) { fprintf(stderr, "(parent_process>created process with id: %d)\n", child_2); }
    
    if(child_2 == -1) {
        perror("fork2 error occurred");
        exit(1);
    }

    if(child_2 == 0) {     // step6 
        if(debug) { fprintf(stderr, "(child2>redirecting stdin to the read end of the pipe…)\n"); }
        fclose(stdin);     // 6.a
        dup(pipefd[0]);     // 6.b
        close(pipefd[0]);   // 6.c
        
        if(debug) { fprintf(stderr, "(child2>going to execute cmd: tail -n 2…)\n"); }
        if(execvp(tailCmd, tailArgs) < 0) {     // 6.d
            perror("execvp error occurred");
            _exit(-1);
        }
        _exit(0);

    } else {        // step7
        if(debug) { fprintf(stderr, "(parent_process>closing the read end of the pipe…)\n"); }
        close(pipefd[0]); 
    }    
    
    if(debug) { fprintf(stderr, "(parent_process>waiting for child1 process to terminate…)\n"); }
    waitpid(child_1, &status1, 0);      //step8
    
    if(debug) { fprintf(stderr, "(parent_process>waiting for child2 process to terminate…)\n"); }
    waitpid(child_2, &status2, 0);      //step8
    
    if(debug) { fprintf(stderr, "(parent_process>exiting…)\n"); }
    return 0;
}